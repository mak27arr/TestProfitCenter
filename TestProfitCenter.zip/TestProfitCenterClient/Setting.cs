﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace TestProfitCenterClient
{
    public class Setting
    {
        public string localIPAddr = "127.0.0.1";
        public string mcastAddress = "224.168.100.2";
        public int mcrtPort = 11000;
    }
}
