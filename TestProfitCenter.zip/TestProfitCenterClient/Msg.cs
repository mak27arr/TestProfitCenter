﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestProfitCenterClient
{
    class Msg
    {
        public long msg_id;
        public int value;
    }
}
